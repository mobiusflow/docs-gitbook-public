# MobiusFlow® Connector Firmware

## Part numbers

- EXT001 868MHz WiFi WPO
- EXT002 868MHz WiFi EnOcean
- EXT00101 868MHz WiFi/PoE None, WPO
- EXT00102 868MHz WiFi/PoE None, EnOcean
- EXT00110 868MHz WiFi/PoE WPO, None
- EXT00112 868MHz WiFi/PoE WPO, EnOcean
- EXT00120 868MHz WiFi/PoE EnOcean, None
- EXT00121 868MHz WiFi/PoE EnOcean, WPO

- EXT101 915MHz WiFi WPO
- EXT102 915MHz WiFi EnOcean
- EXT10101 915MHz WiFi/PoE None, WPO
- EXT10102 915MHz WiFi/PoE None, EnOcean
- EXT10110 915MHz WiFi/PoE WPO, None
- EXT10112 915MHz WiFi/PoE WPO, EnOcean
- EXT10120 915MHz WiFi/PoE EnOcean, None
- EXT10121 915MHz WiFi/PoE EnOcean, WPO

## Updating the firmware

The new firmware can be uploaded to a connector from the About page in the connector config app.
See https://docs.mobiusflow.com for more information

Copyright (C) 2022, MobiusFlow®
